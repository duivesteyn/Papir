Kindle app-icon pack for Papir — generated, no stock art.

The papir mark is the launcher's approved glyph from
art/Iconi/Papir-launcher-glyph-432.png, unchanged except for its size:
fitted to 0.315 of the 108dp canvas so launcher masks stop cropping
it. The Kindle silhouettes are drawn from scratch by
android/tools/make-icons.py.

Folders: papir, then one per Kindle family.
  kindle-scribe       note tablet with the pen parked alongside
  kindle-paperwhite   thin side bezels, wide chin, round home button
  kindle-basic        even bezel all round, no button
  kindle-colorsoft    the cover on the page is in colour
  kindle-oasis        side spine with page-turn buttons
  kindle-voyage       flush glass front, no chin
  kindle-keyboard     keyboard under the page
  kindle-touch        touch ripple and a home bar
  kindle-dx           landscape page over a keyboard
  kindle-generic      plain slab for anything unmatched

Each Kindle folder holds the transparent glyph (…-glyph-1024.png),
the same glyph on the forest field (…-on-forest-1024.png) and baked
tiles at 16, 32, 64, 128, 256, 512 and 1024 px. The papir folder stops
at 432 px: that is the resolution of the approved launcher glyph, and
nothing here upsamples it. `android/` holds what the app
consumes: the 432 px adaptive-icon foregrounds (66dp safe-zone
padding, so launcher masks never crop them) and the matching
adaptive-icon XML.

How Papir picks a mark: the Kindle name on the account is matched in
this order — scribe, colorsoft, oasis, voyage, keyboard, dx,
paperwhite, touch, basic — first hit wins, and anything else gets the
generic slab. "All devices", or no choice yet, shows the papir mark.

Palette: forest #123325, ivory #F3EADB, with sage #7FA88E, mist
#BFD6D0 and taupe #C9BFA9 only on the Colorsoft cover. No Amazon
trade dress, no wordmark.
