Papir — macOS Icon Suite & Brand Assets
Tagline: "A little less screen time."

Contents
--------
01_Primary_ForestGreen/
  - Papir.icns                       Compiled macOS icon bundle (16–1024px)
  - Papir.iconset/                   Xcode / iconutil PNG set
  - Papir-Primary-1024.png           Apple HIG 824x824 squircle on 1024x1024 canvas
  - Papir-Primary-FullBleed-1024.png Full-bleed square (for iOS/iPadOS/Xcode AppIcon)

02_Dark_Midnight/
  - Dark Mode / Midnight Green edition (.icns, .iconset, 1024px HIG & FullBleed)

03_Light_Cream/
  - Light / Parchment Cream edition with Forest Green plane (.icns, .iconset, 1024px HIG & FullBleed)

04_Transparent_NoBG/
  - Papir-Transparent-Cream-1024.png        Standalone cream paper plane + subtle shadow (no green bg)
  - Papir-Transparent-Cream-Flat-1024.png   Standalone cream paper plane, zero shadow
  - Papir-Transparent-Cream-TightCrop.png   Tightly cropped for README / web headers
  - Papir-Transparent-Green-*.png           Same 3 variants in Forest Green (for light backgrounds)
  - Papir-Transparent.icns & .iconset/      Floating transparent macOS dock icon

05_MenuBar/
  - Papir-MenuBar-Template.svg              Clean geometric vector template
  - Papir-MenuBar-Template@1x/@2x/@3x.png   Pure black template PNGs (set NSImage.isTemplate = true)
  - Papir-MenuBar-White@1x/@2x/@3x.png      Pure white PNGs for dark menu bars / non-template use

06_Document_Icons/
  - Papir-Doc (.papir), Papir-Doc-EPUB, Papir-Doc-PDF (.icns, .iconset, 1024px PNG)

07_Web_And_Brand/
  - favicon.ico, favicon-32x32.png, apple-touch-icon.png, icon-192.png, icon-512.png
  - colors.json (hex + RGB color palette)
